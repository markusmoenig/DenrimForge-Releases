"""Freedesktop launcher generation for portable and installed Linux packages."""

# %k is passed as a separate argument, never interpolated into executable code.
# Desktop environments may supply either a local filename or a file URI.
PORTABLE_CODE = (
    "import os,sys;from pathlib import Path;from urllib.parse import unquote,urlsplit;"
    "location=sys.argv[1];"
    "location=unquote(urlsplit(location).path) if location.startswith('file:') else location;"
    "binary=str(Path(location).resolve().parent/'forge-app');"
    "os.execv(binary,[binary]+sys.argv[2:])"
)


def exec_argument(value):
    """Quote one Exec argument through both Desktop Entry escaping layers."""
    value = str(value).replace("\\", "\\\\")
    for character in ['"', '`', '$']:
        value = value.replace(character, "\\" + character)
    value = value.replace('%', '%%').replace("\\", "\\\\")
    return '"' + value + '"'


def portable_exec():
    return 'python3 -c ' + exec_argument(PORTABLE_CODE) + ' %k %f'


def installed_entry(template, executable):
    """Replace the portable bootstrap; installed launchers do not need Python."""
    return '\n'.join(
        'Exec=' + exec_argument(executable) + ' %f' if line.startswith('Exec=') else line
        for line in template.splitlines()
    ) + '\n'


MIME_TYPE = "application/x-denrimforge"


def thumbnail_entry(executable):
    return ("[Thumbnailer Entry]\nTryExec=" + str(executable) + "\nExec=" +
            exec_argument(executable) + " %i %o %s\nMimeType=" + MIME_TYPE + ";\n")


def mime_definition():
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">'
            '<mime-type type="' + MIME_TYPE + '"><glob pattern="*.denrimforge"/>'
            '</mime-type></mime-info>\n')
