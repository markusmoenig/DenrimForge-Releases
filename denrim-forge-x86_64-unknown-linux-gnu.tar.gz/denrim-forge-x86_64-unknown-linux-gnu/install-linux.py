"""Install this extracted Linux package's launcher and icon for the current user."""
import os
import shutil
import subprocess
from pathlib import Path

from linux_launcher import installed_entry, thumbnail_entry, mime_definition

source = Path(__file__).resolve().parent
app_id = "com.moenig.denrimforge.rust"
share = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))
app = share / app_id
app.mkdir(parents=True, exist_ok=True)
shutil.copy2(source / "forge-app", app / "forge-app")
(app / "forge-app").chmod(0o755)
icon = share / "icons/hicolor/256x256/apps" / (app_id + ".png")
icon.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(source / "icon.png", icon)
launcher = share / "applications" / (app_id + ".desktop")
launcher.parent.mkdir(parents=True, exist_ok=True)
launcher.write_text(installed_entry(
    (source / (app_id + ".desktop")).read_text(encoding="utf-8"), app / "forge-app"
), encoding="utf-8")
launcher.chmod(0o755)
print(launcher)

if (source / "forge-thumbnail").is_file():
    preview = app / "forge-thumbnail"
    shutil.copy2(source / "forge-thumbnail", preview)
    preview.chmod(0o755)
    entry = share / "thumbnailers" / (app_id + ".thumbnailer")
    entry.parent.mkdir(parents=True, exist_ok=True)
    entry.write_text(thumbnail_entry(preview), encoding="utf-8")
    mime = share / "mime/packages" / (app_id + ".xml")
    mime.parent.mkdir(parents=True, exist_ok=True)
    mime.write_text(mime_definition(), encoding="utf-8")
    updater = shutil.which("update-mime-database")
    if updater:
        subprocess.run([updater, str(share / "mime")], check=True)
