# Desktop document previews

Forge documents store a PNG at `previews/thumbnail.png`. Swift already supplies a Finder Quick Look thumbnail extension. Rust saves now refresh the same shared entry, including Save As and Save Backup. This preview is a small neutral rendering of visible authored geometry and paint color; it is not a Studio/path-traced image, and does not evaluate procedural materials, height or live subdivision.

## Windows Rust package

Extract the entire package to its permanent location and launch Forge. Starting in v1.6.6, Forge registers previews automatically in a background worker once per package path/version. **File > Enable Document Previews** remains available to retry registration manually, as does `register-previews.cmd`. It registers the packaged `forge_thumbnail.dll` for the current user, without administrator access. Explorer must have thumbnails enabled rather than “always show icons”. Reopen the folder after registration; old cached icons may require a thumbnail-cache refresh. Moving the package requires registering again from its new location. Run `unregister-previews.cmd` before removing the package.

The provider implements `IInitializeWithStream` and `IThumbnailProvider` for Explorer's isolated thumbnail host. It reads only the embedded PNG, limits decompression/image allocation, and does not launch Forge or create a GPU device. Registration does not disable isolation. Native Explorer acceptance still needs Windows testing.

## Linux Rust package

Run `python3 install-linux.py` from the extracted package. It installs the application, companion thumbnail generator, user MIME definition and `.thumbnailer` entry under `XDG_DATA_HOME` (normally `~/.local/share`). The `.deb` installs equivalent system entries. A file manager supporting freedesktop thumbnailers must have local file thumbnails enabled. Restart the file manager after installation if necessary.

The CLI can also verify a saved document directly:

```
forge-thumbnail model.denrimforge thumbnail.png 256
```

Old Rust documents without an embedded PNG acquire a preview when resaved. CLI extraction supports both DFPACK1 and compressed DFPACK2 containers. Shared saves retain other assets and Swift-only editor fields.

## Checks

Release tests cover bounded streaming extraction, truncated input, PNG generation, refresh after a material color change, empty documents, document preservation and Windows/Linux package contents. The Windows interface/refcount regression runs on Windows in the desktop release workflow. Finder/Explorer/file-manager cache behavior remains a native acceptance check, not established by these tests.
