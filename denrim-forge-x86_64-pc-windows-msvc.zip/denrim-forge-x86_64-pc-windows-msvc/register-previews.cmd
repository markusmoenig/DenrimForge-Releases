@echo off
set "forge_thumbnail_clsid={C7F4B6A1-8324-4F8D-A3E0-357ADC8D1531}"
reg add "HKCU\Software\Classes\CLSID\%forge_thumbnail_clsid%\InprocServer32" /ve /t REG_SZ /d "%~dp0forge_thumbnail.dll" /f
if errorlevel 1 exit /b 1
reg add "HKCU\Software\Classes\CLSID\%forge_thumbnail_clsid%\InprocServer32" /v ThreadingModel /t REG_SZ /d Both /f
if errorlevel 1 exit /b 1
reg add "HKCU\Software\Classes\.denrimforge\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}" /ve /t REG_SZ /d "%forge_thumbnail_clsid%" /f
if errorlevel 1 exit /b 1
reg add "HKCU\Software\Classes\SystemFileAssociations\.denrimforge\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}" /ve /t REG_SZ /d "%forge_thumbnail_clsid%" /f
