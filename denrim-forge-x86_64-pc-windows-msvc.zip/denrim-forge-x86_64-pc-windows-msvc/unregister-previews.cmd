@echo off
reg query "HKCU\Software\Classes\.denrimforge\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}" /ve | findstr /i "C7F4B6A1-8324-4F8D-A3E0-357ADC8D1531" >nul
if not errorlevel 1 reg delete "HKCU\Software\Classes\.denrimforge\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}" /f
reg delete "HKCU\Software\Classes\CLSID\{C7F4B6A1-8324-4F8D-A3E0-357ADC8D1531}" /f
reg query "HKCU\Software\Classes\SystemFileAssociations\.denrimforge\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}" /ve | findstr /i "C7F4B6A1-8324-4F8D-A3E0-357ADC8D1531" >nul
if not errorlevel 1 reg delete "HKCU\Software\Classes\SystemFileAssociations\.denrimforge\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}" /f
