# Denrim Forge for Windows and Linux

This directory contains the native Rust port of Denrim Forge. The Apple app
remains in `DenrimForgeApp` and `Sources`; both implementations live in this
repository and share the `.denrimforge` format, fixtures, assets, and behavioral
expectations.

The Rust application is not a web wrapper. `forge-app` creates a native `winit`
window and a native `wgpu` surface. `forge-render` owns Forge's GPU work while
`forge-ui` contributes egui paint meshes to the same frame.

## Crates

- `forge-core`: portable scene, mesh, selection, action, and undo model.
- `forge-format`: byte-compatible `.denrimforge` container and codecs.
- `forge-render`: wgpu viewport, picking, and render graph.
- `forge-ui`: Forge's egui controls and layouts.
- `forge-localization`: Fluent message bundles and English fallback handling.
- `forge-ai`: provider-independent, revisioned AI protocol types.
- `forge-app`: native window, event loop, GPU surface, and composition.
- `forge-android`: Android viewport bring-up using the shared renderer; see
  [Android setup and scope](android/README.md).

## Run

```sh
cargo run -p forge-app
```

For an optimized release build:

```sh
cargo run --release -p forge-app
```

Validate both compilation profiles when changing egui integration: some egui
diagnostic fields exist only with `debug_assertions` enabled.

```sh
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace
cargo build --release --workspace
cargo test --release --workspace
```

To open an existing document:

```sh
cargo run -p forge-app -- projects/cat.denrimforge
```

The desktop UI bundles Roboto as its primary proportional font, so text renders
consistently on macOS, Windows, and Linux without depending on system fonts. See
[`forge-ui/assets/fonts/README.md`](forge-ui/assets/fonts/README.md) for source
and license details. Forge's icon-only controls use the Regular Phosphor icon
font through one semantic Rust mapping. The font is embedded in the application,
so icons never depend on a CDN or platform glyph availability; localized hover
help remains the accessible name for every icon button. Third-party attribution
is recorded in [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md).

The current milestone proves the native window and GPU surface, Forge layout,
Swift-compatible package and mesh decoding, and actual scene geometry rendered
by WGSL. The egui menu bar mirrors the Swift command groups, while all semantic
UI text resolves through `forge-localization`; English is bundled today and
additional Fluent locale resources can be added without changing UI call sites.
The viewport has GPU depth testing and native editor navigation:
drag to orbit, two-finger precision scrolling to pan, pinch to zoom on macOS,
mouse-wheel zoom, and Control/Command-scroll as a zoom fallback. The first
modeling slice is functional: depth-aware object picking, shared selection,
grid-aware position/scale/rotation fields, the Swift-style combined move/resize/
rotate gizmo, document revision sync, and coalesced undo/redo all run through
portable `forge-core` commands. The complete Swift action catalog now lives in
`forge-core`, including availability, ordering, shortcuts, detail kinds, and
gizmo metadata. Object, vertex, edge, and face picking use stable document IDs;
component hover/selection markers are depth-tested in the WGPU viewport. The
bottom transform menus expose Swift's World/Local/Selection/View axis spaces
and Origin/Selection/Active center modes. `forge-core` resolves one world-space
transform frame from active object/component IDs (including face, edge, and
vertex orientation), and both WGPU projection and egui dragging consume that
same frame. Move, axis resize, and arbitrary-axis rotation therefore follow the
displayed gizmo, with resize distances and rotation angles snapped through the
project grid.
Shaded, Wireframe, Shaded+Wireframe, and Normals buttons drive distinct GPU
passes; wireframe component picking follows Swift's through-surface behavior.
The Perspective/Isometric control switches the projection used by scene drawing,
component picking, marquee selection, and the transform gizmo together. Its
target, distance, yaw, pitch, 55-degree field of view, orthographic scale,
projection-preserving toggle, and camera-relative pan/zoom rules now mirror
Swift's `CameraState`. The WGPU render pass and all CPU projection consumers use
the same central viewport rectangle, keeping geometry, picking, and gizmos
pixel-aligned. The orientation overlay now includes the Swift utility rail for
locking navigation, framing the current selection, and returning to the scene
center; framing uses the same bounds-to-distance and bounds-to-orthographic-scale
rules as Swift. Its live 104-point view cube follows camera yaw and pitch, uses
Swift's 34-degree face-picking projection, supports drag-to-orbit and face-click
alignment, and exposes the same Top/Front/Right/Back/Left/Bottom context menu.
The
top-left viewport information panel reports the active tool, snap/gizmo state,
selection statistics, active object, and transform just like the Swift editor.
Its operation and Ruler rows grow independently over the GPU viewport, so
status content cannot change the camera projection. Ruler measures exactly two
selected vertices in transformed object space and formats the result using the
project unit. The Swift Center, Base, and Reset origin controls preserve visible
geometry through one atomic mesh/transform/pivot command, while the X/Y/Z 90°
commands use the same undoable object-transform boundary and shortcuts.
Those serializable commands are also the host-side execution boundary that the
Rust ForgeAI adapter can target as its operation vocabulary is ported. Portable
tool transactions already expose preview, commit, and cancel semantics so UI
gestures and AI-issued edits share the same lifecycle.

The Swift primitive strip is functional as well: Box creates directly, while
Cylinder, Sphere, Capsule, and Torus expose the same segment presets (and torus
thickness presets) in native egui menus. Their mesh generators mirror Swift's
default topology, creation uses stable serializable insertion commands, and a
single undo/redo operation restores both the document and its selection.
The bottom quick-command strip now performs Swift-compatible object/face
duplication, face separation, and object/face deletion. These operations renew
component IDs, prune orphaned geometry, reconcile scene hierarchy links, and
remain atomic across undo and redo.

The action panel also executes Forge's topology-selection command set through
the shared core session: Select Loop (vertex, edge, and face variants), Select
Edge Ring, Select Boundary, Select Connected, Select Coplanar, Select Hard
Edges, Select Open Edges, Grow Selection, and Shrink Selection. Their mesh
traversal and adjacency rules are direct ports of the Swift implementation.
Like Swift, these commands update selection state without adding geometry undo
entries, which keeps the same entry point suitable for UI shortcuts and future
ForgeAI selection operations.

The action sidebar mirrors Swift's three display modes and cycle order: the
300-point full cards, the 176-point icon-and-name rail, and the 66-point
icon-only rail. Both compact rails keep the action groups scrollable, preserve
the full 44-point button hitboxes, show active tools with the Forge accent, and
keep modal Apply/Done controls available below the list. Transform Details are
collapsed on a fresh launch, matching the Swift default.

Fill Holes completes every open boundary in selected objects, or only the open
boundary components touched by selected edges, while preserving Swift's face
and edge selection results. Cleanup Mesh runs the same compound repair order:
weld coincident vertices, remove degenerate polygons, remove coincident
opposing internal polygons, and propagate consistent winding across connected
topology before orienting each component outward. Both are atomic shared-core
commands with undo/redo and keyboard shortcuts, so the action panel and future
ForgeAI calls use identical geometry behavior.

Join now follows Swift's scene mutation contract as well: only selected objects
with mesh data participate; the active mesh object remains the target; every
source mesh bakes its local transform and pivot before concatenation; and the
target transform/pivot reset after joining. Empty selected groups are ignored,
deleted child references are reconciled, the target keeps its identity and
parent, and the entire remove/reinsert operation is one serializable command
with exact hierarchy restoration on undo.

Mirror and Symmetrize use Swift's local/world-origin rules, seam welding,
clipping, winding, selection preservation, and atomic undo behavior. The
bottom symmetry popover also mirrors the Swift grouping and dimensions: live
X/Y/Z planes (including combined-axis counterpart updates), Origin,
positive/negative Symmetrize rows, and object-only Mirror commands. Live
symmetry is serialized with the project and is applied by the shared core
transform path, so UI drags and future ForgeAI transforms resolve counterparts
the same way.

Action cards register their complete painted rectangle as one click target,
including the icon, localized title, description, shortcut, and padding. This
keeps sidebar presses owned by the sidebar instead of leaving only a small
child response interactive.

The first topology-changing action-panel commands are implemented through a
second shared core boundary: Split Edge, Subdivide, Relax, Merge, Connect, Fill,
Bridge, Triangulate, Flip Normals, Recalculate Normals, Weld Vertices, and
Remove Degenerates.
Subdivide reuses shared-edge midpoints and updates neighboring polygon
boundaries just like Swift; Relax preserves open boundaries and original face
winding; Connect cuts a verified edge chain through shared and coplanar faces;
Fill supports sorted vertex polygons, selected closed edge loops, and whole
open-boundary completion; Bridge uses Swift's non-crossing edge pairing and
best-matched face loops. These commands preserve Swift's resulting selection
modes and IDs, replace all affected object meshes atomically, and restore both
geometry and selection through undo/redo.

Offset and Flatten now follow the Swift tool workflow as well. Offset exposes
the same signed `-100...100` distance, X/Y/Z world-axis choices, project-unit
suffix, and grid-derived precision; it commits object transforms or selected
component positions as one undoable command. Flatten exposes Angle/X/Y/Z,
computes Swift's Jacobi best-fit plane when requested, and projects every target
through one shared world-space plane across selected objects. Both tools retain
their selection and active-tool state after Apply, and the document reader now
preserves Swift's `mm`, `cm`, `m`, or `in` project unit.

Circlify is also a direct Swift geometry port. Vertex and edge selections must
form closed, non-branching loops; selected face regions use their closed
boundary. Influence, Preserve Surface, and Regular Spacing have the same Swift
defaults and controls, the cached WGPU preview calls the exact commit operation,
and Apply replaces all affected object meshes in one undoable command while
restoring the original selection.

Push/Pull follows the Swift face workflow from selection through rendering. Its
signed `-4...4` amount uses the grid snap step, live preview is non-destructive,
and Apply records one atomic mesh command. The viewport arrow starts at the
first selected face center, follows its transformed outward normal, uses the
same minimum/grid-derived length and camera-dependent drag scale as Swift, and
commits a snapped drag as one undoable edit. The active tool and selected moved
faces remain available for a subsequent operation or future ForgeAI command.

Extrude now covers both Swift modes rather than a simplified face translation.
Connected face regions share duplicated boundary vertices, Per Face gives each
polygon its own shell, and edge extrusion is accepted only for true open
boundary edges so it cannot create a non-manifold third face. Parameter edits
render a cached preview with the generated outer faces/edges highlighted. The
modal arrow uses the selected face normal or Swift's boundary-edge direction,
can be grabbed along its full shaft, follows the extrusion while dragging, and
keeps a gizmo drag scoped to the active object while Apply supports all selected
objects. Both paths commit through the same atomic mesh-command boundary.

Inset matches Swift's Per Face and connected-region topology, including shared
inner vertices, boundary-only side rings, convex-region deformation, and the
selection-derived maximum amount. Its adaptive slider range, generated-face
preview highlight, boundary outlines, corner connector lines, and draggable
corner handles all use the same geometry as Apply. The viewport drag snaps in
world space through the active project grid, while the sidebar retains Swift's
selection-derived adaptive range. Modal cubes use Swift's 14/17-point normal
and hot sizes with a DPI-independent 22-point hit radius. Parameter tools expose
separate Apply and Done controls: Apply records the edit and leaves the tool
active, while Done (or Escape outside a drag) returns to Move and clears the
temporary preview.

Arc now follows the Swift quad-face workflow: Primary/Rotated chooses the same
length and curve axes, Height uses the grid step, Segments is clamped to 2...24,
and Apply replaces each quad with the curved strip plus two correctly oriented
caps as one undoable mesh command. Its cached preview highlights the generated
faces, while the viewport shows the original face outline and a tip-only,
diamond-style normal handle whose drag adjusts the snapped height.

Knife now keeps an editable draft on one selected face, snaps first to nearby
face vertices and otherwise to the project grid before projecting back onto the
face plane, and supports draggable points. Two points use Swift's linear face
split; three or more create the closed inner polygon and surrounding ring.
Apply, Undo Point, Cancel Cut, Escape, selection updates, and undo all flow
through the shared editor session rather than a UI-only geometry path.
Line and polygon cuts retain source materials, interpolate corner UVs, and
reproject face paint using Swift's generated paint coordinates and aspect-aware
grid dimensions. CPU-generated Swift fixtures check the resulting faces, UVs,
and paint cells; an editor regression checks active-map capture and undo/redo.
Recalculate Normals orients connected shells before filtering selected faces and
reverses UVs with vertex winding, including polygon-cut normal repair.

CSG Subtract follows current Swift's face-plane subtraction, clipped reversed
cutter faces, quantized vertex reuse, and structural-validation commit gate.
Projected-footprint cuts use equal-corner rings, rectangular slabs, triangulated
rings, and projected assignments in Swift's order. The active selected object is
the target; world-space geometry, reset transform/pivot, UV state, cutter removal,
and animation-track pruning are one serializable command batch with undo/redo.
The action works in all three list layouts. The full list includes Swift's
target/cutter label and Preview CSG Result toggle. Opening loops and result-mesh
overlays use Swift's colors/alpha and are cached by scene revision, selection,
and preview mode; camera motion only reprojects the cached points. CPU fixtures
cover ten current Swift boolean cases, and tests verify command replay, undo,
selection, animation retention, and overlay colors/capacity. Native GPU appearance
still needs manual verification. Flip Normals now reverses corner UVs together
with vertex winding.

Cut Through now implements Swift's exterior endpoint matching and blocker
analysis, full-face openings, clear tunnels, and intersecting-tunnel merging.
The merge follows blocker imprinting, shared-edge insertion, split wall bands,
endpoint opening, and inside-volume cleanup. Nine CPU-generated Swift fixtures
compare the endpoint/blocker analysis, oriented geometry, UVs and materials,
and operation counts. The action dispatches in all three list layouts with
localized Swift status text and undoable mesh/UV/selection updates.

Removal undo now restores exact parent links and authored child order with a
serializable RestoreObjectHierarchy command after reinserting removed objects.
Regression cases include surviving children/grandchildren and CSG cutters with
children. The remaining tool audit checks behavior and appearance preservation;
enabling a catalog entry alone does not establish full Swift parity. The
appearance audit results for Extrude and subsequent generated-face tools are
recorded below. Mesh-center calculations now support arrays
above 65,535 vertices; a translated large-mesh Cut Through regression exercises
that former limit.

Loop Cut traverses the same connected quad strip from selected edge seeds, or
from shared edges between selected quad faces. Position uses Swift's
`0.05...0.95` range and `0.05` step; Mirror inserts the reflected second loop
while deduplicating the center. Its generated-face preview and Apply share one
topology operation, and Apply commits all affected objects atomically before
returning to Move.

Edge Slide orders each selected non-branching edge component, derives the
surface-side direction from averaged vertex normals and component tangents,
then moves each vertex toward the signed adjacent rail. The Swift `-1...1`
control and `0.05` step drive a non-destructive preview; invalid or degenerate
results are rejected and changed winding is restored. Apply preserves the slid
edge selection and records one atomic multi-object edit, while Done exits
without committing the preview.

Bevel exposes object, edge, and face selection paths with rounded strips from
1...8 segments; current Swift algorithm coverage is detailed below. The localized Amount
control and viewport amount handle both follow the project grid in world space;
the blue segment handle uses the same 28-point step.
Object mode exposes all six bounds handles, edge and face modes select one
representative handle per control, and the generated-face preview is produced
by the same core operation as the atomic Apply command. Done or Escape clears
the preview without modifying the mesh.

Solidify follows Swift's face-only shell workflow. It offsets shared vertices
along averaged face normals, reverses the generated outer faces, closes region
boundaries with side quads, and preserves the source surface when thickening a
fully selected open mesh. Thickness uses project-grid precision in the sidebar;
Inward changes the signed preview direction. The viewport arrow retains Swift's
visible minimum and uses the same world-space project grid without committing during a drag,
while Apply selects the generated shell through one undoable core command and
Done or Escape discards the preview.

Align to Face is a true pick-driven tool rather than an enabled placeholder.
It retains the active source-face selection while the viewport resolves an
unselected destination face, rotates the source normal to oppose the target,
and translates every selected region vertex onto the destination center. The
destination stays fixed, the edit is one undo step through the shared command
path, and a successful pick returns to Move; Done or Escape cancels without an
edit.

Lathe mirrors Swift's object-mode profile workflow. Viewport clicks and point
drags intersect the world `Z=0` construction plane, clamp to its positive
radius/height quadrant, and snap through the project grid. The native overlay
shows the same 0...3 plane, axes, ticks, editable profile, Catmull-Rom sampled
curve, optional cap guides, and rotational rings, with live R/Y status. The
sidebar retains Swift's 16-segment, one-subdivision, two-cap defaults and its
3...64 / 1...16 ranges. Create Lathe inserts and selects one named object via
the shared command path and one undo step; Undo Point, Done, and Escape keep
draft cancellation explicit.

Array mirrors Swift's object-, face-, and paint-selection workflow with the
same Count 4, Offset (2, 0, 0), radial Z/world-center/90-degree defaults and
control ranges. Offset components use the active project grid. Live previews
run the exact non-destructive Apply path; Done discards them, while Apply makes
fresh mesh/component IDs, selects only the generated objects, and records the
generated children plus their Array group as one undoable command. The command
API already accepts an explicit point center for future ForgeAI use even though
the current UI exposes Swift's World and Selection center choices.

Sub-D preview persists Swift-compatible per-object levels `0...3` and evaluates
Catmull-Clark surfaces without replacing the editable base topology. Edge
creases propagate into child edges, and Freeze bakes the evaluated visible
surface through one undoable core command before returning to object mode.
The bottom visibility control mirrors Swift's Hide Selected, Hide Unselected,
and Reveal All menu for both face and object modes. Hidden face IDs serialize
with the document, are removed before Sub-D evaluation, rendering, and face
picking, and are cleared only when revealed or baked by Freeze. These
visibility mutations use the same serializable command boundary intended for
future ForgeAI operations.

The current Swift UV workflow is available in Rust: multiple named maps, active
map switching, seams and edge loops, island selection, seam-aware unfold,
planar/box/cylinder/sphere/Smart projections, packing, and the face UV transform
and clipboard tools. The localized UV sidebar follows Swift's control order,
defaults, preview, and immediate editing behavior. Changes record complete mesh,
map, seam, and atlas state through serializable `ForgeCommand::SetObjectUvs`,
including reconciliation during topology edits and exact undo/redo restoration.
Primitives carry Swift's corner UVs; copies remap UV ownership, and Sub-D
interpolates corner UVs while retaining face materials.

Paint prepares the active UV layout and a full-resolution material-index atlas.
Brush dabs, continuous strokes, enabled symmetry combinations, atlas reprojection,
material changes, and the eyedropper use this state. A whole stroke is one undo
entry. The GPU samples the atlas with perspective-correct UVs; it is not reduced
to the old face-grid resolution. Swift's aspect-adjusted 64-cell compatibility
grids are maintained for interoperability, and existing legacy grids can migrate
to the current atlas. Texture visibility uses the existing Textures control.

`forge-format` reads and writes UV workspaces and material atlases in Swift's
DFPACK1/DFMESH1 representations, including Foundation's optional UUID paint cells.
The encoder covers the Rust project model; it does not preserve unsupported
Swift-only metadata. The `uv_fixture` example writes a new disposable document
for interoperability checks; it is not a replacement for a complete file-save UI.

The viewport uses Swift's world-space Y=0 grid, snap spacing, major/minor lines,
axis colors, labels, and scene extent. Camera projection and depth testing keep
it anchored to the scene. Paint palettes have explicit fitting column sizes;
the sidebar separator and egui indent guide no longer cross the controls.

UV regression fixtures are generated by executing the Swift core, not by copying
Rust output. Tests compare projection and unfold coordinates against that output,
and cover maps, seams, packing, atlas sampling, mirrored brush strokes, undo,
persistence, and palette layout. Native checks exercise painting and undo/redo.
An additional GPU readback test validates actual atlas rendering and shader
creation on a host with a native GPU:

```bash
cargo test -p forge-render native_gpu -- --ignored --nocapture
```

Studio now uses the current Swift forward material renderer: GGX direct lighting,
roughness and metallic response, HDR diffuse/specular lighting, wax scattering,
emission, and a separate sorted glass pass. Painted atlas cells supply complete
material parameters to the same shader. The six bundled Radiance environments
are shared with Swift; Rust builds its 96-pixel GGX-prefiltered cubemaps and BRDF
integration lookup using Swift's 32-sample formulas.

The render graph includes caster-framed soft shadows, detected floor reflections,
normal/material buffers, SSAO, narrow and wide bloom, refraction and subsurface
postprocessing, four tone mappers, the studio color grade, vignette and idle
refinement. Refinement resets on edits, selection, navigation and resize, and
stops accumulating at Swift's sample cap. Editor grid, selection boundaries and
gizmos are composited after presentation with scene depth. The shadow attachment
uses portable Depth32Float with manual PCF; Swift stores sampled depth as R16Unorm.
The current Swift renderer disables its legacy SSR/procedural post-reflection
branch, and Rust follows that behavior.

Studio and its toolbar toggles edit serialized `RenderSettings` through
`ForgeCommand::SetRenderSettings`, including undo/redo and Swift package decoding
and encoding. The anchored Renderer popover mirrors Swift's controls and ranges.
Import HDR uses a native file dialog and a validated, collision-safe environment
library in the platform data directory. All application-authored control labels
and import errors are localized. Asset import/export is described below.

The UV and Paint sidebars scroll without visible scrollbar indicators. Modeling
settings use Swift's 292-point overlay above the bottom-left HUD in Full, Names,
and Icons modes. Apply/Done remain in the action panel; compact modes pin these
buttons below the scrolling list. Rail labels paint inside the scroll clip and
do not register widgets over the buttons. Pointer regression tests exercise a
settings change, Apply, Done, and Undo in each display mode.

Following reports of macOS out-of-memory lockups during native UI automation,
native checks resumed with one instance at a time and an RSS watchdog. See
[NATIVE_VERIFICATION.md](NATIVE_VERIFICATION.md). Short monitored sessions and
small GPU readback tests do not establish sustained memory stability at Retina
resolutions.

The desktop loop now sleeps between requested repaints and stops idle refinement
at its sample cap. Before any frame uploads or resize allocations, a nonblocking
GPU poll gates work on completion of the previous submission. The surface is
acquired before egui uploads, so failed acquisition cannot accumulate unsubmitted
staging buffers. Resize events coalesce; equal-size targets and grid vertex
buffers are reused. CPU tests exercise prolonged GPU-busy scheduling, redraw rate
limiting, idle shutdown, and egui timer scheduling. These mitigations do not prove
the cause of the reported system lockups. Studio still retains substantial
full-resolution intermediate textures; reducing that fixed footprint and measuring
app versus capture-process memory remain outstanding.

The desktop File menu provides New, Open, Open Recent/Clear Menu, Save, Save As,
Revert to Saved, Close, and Quit, with separators and Command/Ctrl shortcuts.
Document actions operate in the current native window. New/Open/Close/Quit
protect unsaved changes with Save/Don’t Save/Cancel; Revert requires confirmation.
The title tracks the file and edited state, including undo back to the saved state.
Open resets editing history and transient tools. Native dialogs filter Forge
packages. Saves replace files atomically, retain package assets and Swift-only
manifest state, and keep the editing session intact on failure. Export formats
remain disabled. Camera, projection, grid, component selection, and the active tool are restored
from Swift packages and saved back using Swift's field names. Restoring a tool
never executes an immediate modeling command.

Studio postprocessing bypasses empty background pixels, preserving Swift's
0.10/0.13/0.17 viewport color when Studio or exposure changes. The native readback
regression covers this but remains ignored until GPU validation resumes.

Menu bars and nested menus use 14-point Roboto. Persistent viewport chrome and
modeling overlays stay below the popup/menu layer, including where File commands
or Renderer settings overlap the info panel or view cube. CPU interaction tests
verify the full File menu, its separators, and popup hit testing in that overlap.
Studio renders independently of the remembered editor normals/wireframe mode;
leaving Studio restores that mode. Both the UI and renderer enforce this boundary.

The screenshot parity pass uses Swift's 300-point action sidebar, transparent
unselected action rows, 14-point titles, 11.5-point descriptions limited to two
lines, six-point row spacing, and the same Transform & Select grouping. The info
HUD sizes to its status text instead of a fixed 470-point width and uses Swift's
caption sizes, row spacing, black 22% fill and white 10% outline. Viewport controls
use the authored per-mode colors, 40x36 or 30x28 hit areas, three-point spacing,
and subtle translucent selected backgrounds. Mixed icon/text labels explicitly
select the Phosphor font for icons and Roboto for text. The texture-palette and
ambient-occlusion glyphs use Swift's custom vector paths and palette colors.
Native visual verification
remains deferred; these changes do not establish pixel-for-pixel equivalence with
SwiftUI materials or SF Symbols.

The Preferences gear opens a 270-point anchored panel following the desktop
Swift control order: Animated Buttons, Action Panel Layout, Viewport Info,
Xray Components, Show Pivots, Video Feedback, Units, and Reference Image.
Interface settings persist separately from documents in the platform config
folder and survive New/Open. Units and reference-image changes use serializable,
undoable core commands and round-trip through Swift packages (including base64
image data). Reference images support import/replace through a native file
chooser, visibility, locking, opacity, size, centering, removal, and viewport
dragging. Slider and drag gestures produce one undo step; image bytes are shared
across history entries. Decoding is allocation-limited and the single cached
reference texture is capped at 2048 pixels per dimension. Apple Photos and the
Swift-only ForgeAI IPC preferences footer are not implemented in this panel.
Video feedback uses bounded, expiring click ripples and key badges. Xray overlays
use Swift's 22% opacity; optional pivot axes follow parent transforms, including
reflections. Native GPU/UI verification remains deferred.

Preferences now hide their scrollbar while retaining scrolling. The Animation
film button opens the current Swift timeline layout: a 164-point bottom strip
replacing the bottom HUD, with the scene sidebar visible. Explicit Apply/Done
tools must finish before opening it. Clips belong to objects; creating one keys
the selected objects at frame zero, enables Auto Key, and advances to frame 30
(30 fps, 90-frame looping clip). The timeline supports clip selection, renaming,
per-object deletion, frame rate/duration, channel pre/post behavior, synchronized
Preview All Items, transport/scrubbing, three colored key tracks, key selection,
key dragging, cut/copy/paste/delete, and the key inspector. Closing stops playback
and returns rendering to the document's base pose.

The serializable `SetAnimationLibrary` command is shared by timeline edits and
Auto Key. Continuous edits coalesce into one undo step. Manual poses stay
transient until Add Transform Key; both manual and automatic animation authoring
preserve the base object transforms. The current schema-2 Swift animation payload
round-trips in scene.animation. Sampling supports stepped/linear/eased keys,
unwrapped Euler rotations, and constant/repeat/oscillate/offset-repeat channel
behavior. Playback is frame-based with Once/Loop/Ping-Pong evaluation; unchanged
sampled poses reuse the same preview rather than rebuilding render geometry.
The existing single-frame GPU backpressure applies during playback as well.

Animation evaluation fixtures in `forge-core/tests/fixtures/animation-swift`
were generated by compiling and running the current Swift shared animation core
with that directory's `main.swift`; Rust CPU tests compare against those results.
CPU interaction tests cover timeline opening, clip creation, multi-step key drag
undo, Auto/Manual Key, and playback. Native visual/GPU verification is deferred.

The question-mark button now toggles Swift's contextual Help mode. Controls
select an explanation instead of activating: top toolbar, all action list
layouts, viewport/render/camera/history controls, selection and transform
controls, Paint/UV panels, and timeline controls. The bottom-left card follows
Swift's 360-point width, 14-point padding, yellow outline, and animation-aware
bottom offset. It includes the icon, title, action shortcut, and the three
sections “What it does”, “Workflow use”, and “Notes”. Action rows display Swift's
question-mark badges. The timeline key-editing menu remains a menu in Help;
its entries explain Cut/Copy/Paste/Delete without touching keys or clipboard.

The 150 English topics are stored in Fluent, traced from `InterfaceHelpTopic`,
Swift's action localization/catalog, and `DenrimTimelineUI` resources. Capsule
and Torus use the current Swift action catalog's authored help (their help keys
are absent from the Swift string catalog). No translated resources were added.
Help routing and the selected topic are transient UI state, separate from
serializable model commands. Editable fields are disabled before evaluation,
while scroll containers remain enabled and preserve their clipping. Inspection
also works on disabled commands; closing Help restores normal control behavior.
CPU tests cover content completeness, all three action layouts, toolbar/camera
inspection, Paint/UV, scrolling, overlay placement/input blocking, timeline keys,
and clipboard menus. Native visual/GPU verification remains deferred.


## Import and export

The top toolbar uses Swift's “Import and Export” popover, with Import SVG,
a separator, and six export buttons. SVG opens a native file chooser followed
by the width/depth/curve-quality/combine options sheet. Filled SVG paths,
primitive shapes, nested transforms, holes, CSS classes and representative
gradient colors follow the current Swift importer. Unsupported features produce
Swift's localized warnings. Imported fill materials and selected objects are
one serializable, undoable core ImportSvg command.

Exports are implemented in forge-format, with native dialogs and atomic file
writes in forge-app:

- OBJ Texture Bundle writes OBJ, MTL and PNG into DenrimForgeOBJ, using active
  UV paint or Swift's padded per-face fallback for legacy overlapping maps.
- OBJ Vertex Colors uses evaluated geometry, painted quad tessellation, shared
  boundary splits, welded average colors and closed-shell orientation.
- USDZ writes portable USD Preview Surface geometry and textures in an
  uncompressed, 64-byte-aligned package; no SceneKit runtime is required.
- STL writes evaluated visible geometry with outward shell winding in millimeters.
- GLB embeds base/PBR/emissive PNGs, transmission materials, hierarchy and pivot
  nodes, plus frame-baked clips and compatible combined All Items animations.
- Viewport PNG renders a single 1600 × 1200 raster frame without editor overlays,
  reusing the scene resources and waiting for GPU readback before restoring the
  viewport resources.

OBJ retains scene units with a unit comment; USDZ and GLB export meters.
The fixture generator in forge-format/tests/fixtures/swift-export runs the
current Swift core without a native window. Regression tests compare OBJ/MTL,
raw texture pixels, STL, welded vertex colors and GLB scene data against these
reference files. Native PNG export is compiled but has not been run during this
slice, to avoid GPU automation after the reported macOS memory lockups.

Extrude now preserves cap materials, authored UVs and paint in both per-face and
region modes. Its side walls inherit the source material with Swift's default
quad UVs. Arc now generates Swift's strip and semicircular cap UVs, reversing
corner UVs with face winding, and inherits source materials without copying paint.
CPU fixtures in `forge-core/tests/fixtures/swift-extrude` and `swift-arc` compare
these results against the shared Swift implementation. Extrude preview, commit,
active UV maps and undo/redo are covered together. Inset and Solidify now also preserve source material, cap UVs and paint, generate
Swift's wall UVs, and repair normals with corner UV winding preserved. Region
Inset performs structural validation before accepting its result; Solidify skips
degenerate selected faces in the same way as Swift. Fifteen reference cases in
`forge-core/tests/fixtures/swift-inset-solidify` cover appearance, open/closed
surfaces, missing UVs, invalid input, clamping, and inward thickness. Their editor
preview, commit, UV workspace and undo/redo paths are covered. The wider tool
parity audit remains in progress.

Merge Faces inherits the first source face's material and uses Swift's polygon
UVs. Bridge Faces uses the first non-nil source material and reverses corner UVs
with winding; Bridge Edges uses default quad UVs after choosing its orientation.
Fill Face and all Fill Holes branches now assign Swift's polygon UVs, including
triangulated concave boundaries. None of these generated faces copies source
paint, matching Swift. Fifteen CPU reference cases in
`forge-core/tests/fixtures/swift-merge-bridge-fill` verify geometry and appearance;
command tests verify active UV maps and undo/redo restoration.

Triangulate now preserves each source face's material and paint while mapping
corner UVs into Swift's shortest-diagonal quad triangles or polygon fan. Merge
Vertices removes UV entries together with discarded corners, retaining the first
source corner mapped to each survivor. Weld preserves the UV associated with each
surviving consecutive corner, removes duplicate closing UVs, and remaps edge IDs
and creases before rebuilding topology. Missing UV arrays use Swift's polygon
fallback. Split Edge now interpolates midpoint UVs separately on each face and
passes the source crease to both child edges. Sixteen Swift CPU fixtures in
`forge-core/tests/fixtures/swift-corner-edits`
and command undo/redo tests verify these paths.

Editable Subdivide now preserves child materials/paint and interpolates corner,
mid-edge and center UVs, including midpoint UVs inserted into unselected neighbors.
Connect's direct vertex-to-vertex split preserves corner UVs and reprojects paint
with the same transfer as Swift. It preserves the split loop's own winding even
when that differs from the parent concave polygon. Nine CPU reference cases in
`forge-core/tests/fixtures/swift-subdivide-connect` and command tests compare
geometry, appearance, active UV maps, and undo/redo with Swift.

Mirrored Loop Cut now interpolates both cut boundaries in source UV space,
retains source material, and reprojects paint onto each new strip. Reversed seed
edges preserve UV-to-vertex pairing. Edge extrusion assigns Swift's default quad
UVs after determining winding, with no per-face material or paint override.
Nine reference cases in `forge-core/tests/fixtures/swift-loop-extrude` compare
geometry and appearance, and editor tests cover preview, Apply, active UV maps,
and undo/redo. Paint transfer stores only the affected quad's positions rather
than copying the full vertex lookup for each split face.

The scoped selected-edge Bevel path now preserves UVs on retained face patches,
interpolates neighboring edge-insertion and rounded-path UVs, and assigns Swift's
materials and UVs to strips/caps. It retains Swift's unused source vertices and
runs final normal repair. Bevel preview now dispatches the same core operation as
Apply in a temporary session, keeping active UV maps synchronized. Six reference
cases in `forge-core/tests/fixtures/swift-bevel-edges` cover single/disjoint/open
edges with one and three segments and verify preview/Apply/undo behavior.
Object-mode Bevel now uses Swift's dedicated all-edge construction, including
rounded three-path corner patches, odd-segment midpoint insertion into adjoining
strips, higher-valence corner caps, and open-boundary source vertices. Inset
faces retain source materials, UVs and paint; strips and caps use Swift's
respective generated UV mappings. Twelve reference cases in
`forge-core/tests/fixtures/swift-bevel-objects` cover segments 1/2/3/4/8, clamping,
missing UVs, an open face, sheared geometry, a tetrahedron and higher-valence
vertices. Editor checks cover closed topology, preview/Apply UV stability,
active UV maps, and undo/redo. Dictionary traversal is stable in Rust so the
arbitrary generated corner UV orientation does not change between preview and
Apply; reference tests account for Swift's randomized dictionary traversal.
Face and edge Bevel now use the current Swift algorithms throughout the reachable
routing tree. Face mode preserves source IDs/appearance, handles coplanar merges
without removing collinear boundary vertices, clamps full-boundary insets, builds
rounded strips and corner patches, welds and repairs boundaries. Edge mode routes
complete face boundaries, closed loops, shared corners, scoped chains, connected
fallbacks and atomic disjoint passes in Swift order. Continuous paired rounded
paths merge with corner UV compaction. The full intersection check controls the
overshoot retry, and closed-loop fallback subdivision occurs before validation.
The obsolete generic Bevel implementation has been removed.

Twenty face cases and 39 edge-route cases in `swift-bevel-faces` and
`swift-bevel-routes` supplement the earlier 18 Bevel references (77 total).
They verify acceptance/rejection, topology, materials, paint, corner UVs, crease
values and mesh identity. Editor tests cover preview/Apply UV stability,
serialized command replay, selection/tool lifecycle, undo/redo, selection guards
and object transform-root targeting. Apply uses Swift's selection eligibility
in every action-list display mode; status text is localized English matching
Swift. Object Apply keeps Bevel active; edge/face Apply selects the generated
faces and returns to Transform. Native GPU visual checks remain intentionally
skipped while investigating the earlier machine memory failures.

The Scene outliner now supports inline row renaming and descendant deletion
through serializable, undoable commands. Deletion also removes the affected
animation tracks; undo restores the hierarchy and animation library. Long names
truncate while keeping row controls visible, and the outliner scrollbar is hidden.

Action, UV, Paint, and Scene sidebars, Paint HUD, tool settings, and timeline now
use Swift's 180 ms ease-in/out slide-and-fade transitions. Interface Animations
can disable them immediately. Sidebar transitions update the viewport width in
step with the panel; outgoing controls are disabled. Transition state retains
only panel identities and timing, and requests repaint only while moving.

Mirror now carries source materials and paint to mirrored faces, reverses corner
UVs alongside winding, uses Swift's polygon UV fallback, and preserves mirrored
edge creases through welding. Symmetrize interpolates UVs at plane intersections,
keeps UVs paired through seam deduplication/projection, and restores creases on
retained source-edge segments before mirroring. Twenty-two current Swift CPU
fixtures cover all axes, both sides, appearance, closed and open meshes, and
exact/epsilon seams. Both editor commands return to Transform after a successful
edit; Symmetrize follows Swift's transform-root hierarchy targeting in every
component mode. Active UV maps and undo/redo are covered by command tests.

## Native icons and desktop release builds

`rust/icon.png` is embedded in the native window icon (Windows and X11). Wayland
uses the desktop ID `com.moenig.denrimforge.rust` to find the installed launcher
icon. The Windows executable also embeds `packaging/forge.ico` through its Cargo
build script. macOS uses `packaging/forge.icns` in the packaged `.app`; a bare
`cargo run` executable does not acquire a Dock/Finder icon from winit.

After replacing the source PNG, regenerate the tracked platform assets with
`python3 rust/packaging/generate-icons.py` (requires Pillow). The source image is
preserved. The generated ICO contains sizes from 16 to 256 pixels.

`.github/workflows/rust-release.yml` builds native Windows x64 and Linux x64
(Ubuntu 22.04/glibc 2.35 baseline) packages using Rust 1.98.0. macOS releases are
delivered by the native Swift version. Run **Rust desktop builds** manually in
GitHub Actions to obtain archives and SHA-256 files. Pushing a
`rust-v<workspace-version>` tag runs the same checks
and assembles a **draft** GitHub release after all jobs succeed. The tag must match
`Cargo.toml`; ordinary Swift version tags are unaffected. Published releases are
never overwritten by reruns. No workflow has been pushed or run by this change.

Each native job runs formatting, Clippy, CPU tests, then a locked release build.
GPU tests stay ignored. Native Windows/Linux execution must still be verified on
those platforms. Linux requires a working Vulkan driver plus X11 or Wayland;
these archives do not bundle drivers. macOS bundles are ad-hoc signed for testing,
not Developer ID signed/notarized. Windows executables are not Authenticode signed.

For a local macOS package, after `cargo build --release -p forge-app`:

```sh
python3.12 rust/packaging/package.py --platform macos --target aarch64-apple-darwin --binary .target/release/forge-app
```

The packaging script requires Python 3.11 or newer. Build on the matching native
platform and pass its target identifier; Windows uses `forge-app.exe`. Output goes
to `.target/dist`. Extract Linux packages and run `python3 install-linux.py` to
install the executable, desktop launcher and icon under the current user's data
directory. It honors `XDG_DATA_HOME` and needs no administrator access. The Rust
bundle/desktop ID is separate from Swift so both versions can coexist.

### Standalone Debian/Ubuntu installer

Linux release jobs now generate `denrim-forge_<version>_amd64.deb` and a SHA-256
checksum alongside the portable `.tar.gz`. These are downloadable binary files;
there is no AUR, PPA, apt repository, or other package-registry publishing.
The package is marked proprietary (`non-free/graphics`) and includes runtime
files only. Existing GitHub artifact/draft-release handling applies to both formats.

Install a downloaded package with:

```sh
sudo apt install ./denrim-forge_1.5.25_amd64.deb
```

APT installs the required libraries. A compatible Vulkan driver must be installed
for the machine's GPU. The package installs `/usr/bin/forge-app`, its desktop
launcher, icon and package metadata. Upgrades use the same install command with
the new file; uninstall with `sudo apt remove denrim-forge`. User documents and
preferences are outside the package payload and are not deleted by uninstalling.
The separate per-user installer from the tar archive remains optional; remove its
launcher before switching to the system package if both were installed.

To create a `.deb` locally on a matching Debian/Ubuntu host, install `dpkg-dev`
and `desktop-file-utils`, build the Linux release, then run:

```sh
python3.12 rust/packaging/package.py --platform linux --target x86_64-unknown-linux-gnu --binary .target/release/forge-app --deb
```

The packager verifies the ELF architecture, derives linked dependencies with
`dpkg-shlibdeps`, adds the libraries loaded dynamically by the window/renderer,
validates the desktop entry, and builds with root-owned paths using `dpkg-deb`.
It requires no root access to build and never installs or runs Forge during
packaging. Linux CI also builds/extracts a disposable test package. macOS tests
check payload layout and metadata; the native `.deb` build test is skipped there.

Lathe's mesh generation now matches current Swift at the rotation axis: each
zero/epsilon-radius row has one shared pole, and consecutive pole rows generate
no degenerate faces. Sixteen Swift CPU fixtures cover caps, poles, UVs, smoothing,
minimum controls and invalid profiles. Creating an object keeps Lathe active for
another draft; a completed draft producing no faces clears without an undo entry,
and Done still exits. Command tests cover closed-pole adjacency, active UV maps,
repeat naming and undo/redo. This slice verifies geometry and creation lifecycle;
the subsequent preview port below replaces the screen-space handles with
Swift's world-space cube markers.

Lathe preview drawing now uses the GPU component overlay instead of egui's
fixed-size squares. It follows Swift's 0.12-world-unit cube geometry at every
smoothed sample, yellow highlight color, translucent 3-by-3 plane, axis/guide
alphas, 0.08-unit ticks and nonzero-radius cap spokes/rings. Geometry is cached
until the draft/settings change; camera motion only reprojects it. Leaving Lathe
clears the preview. Overlay buffers grow from actual generated vertex counts
before writes. Egui retains only authored-point input: the nearest point within
Swift's 14-point radius wins and stays captured during a drag, without invented
hover enlargement/recoloring. CPU tests check dimensions, opacity, zoom scaling,
cache reuse/clearing and overlapping-point drag selection. Native GPU appearance
has not been visually verified on this machine.

Array appearance now retains Swift's edge creases and remaps hidden faces for
object, face and Paint arrays. The shared whole-mesh and selected-face copy
helpers preserve creases; whole-mesh copies also retain authored loose edges
rather than reconstructing only face boundaries. Twenty-one current Swift CPU
fixtures compare offset/radial arrays on all axes, world/selection centers,
multiple sources, transformed pivots, materials, corner UVs, paint and visibility.
Preview and Apply share this result, with generated hierarchy/selection and exact
undo/redo checked together. Array now creates a named scene layer and assigns its
generated objects and group to it, matching Swift. Duplicate and Separate retain
source layer assignments. Layer metadata survives both new and preserving saves.
These checks do not establish native visual parity. Sculpt is outside the
requested Rust port scope.

Relax now reverses corner UVs when repairing a face's winding, matching current
Swift and keeping authored textures attached to their corners. A current-Swift
folded-surface fixture reproduces the failure before the fix at the UI's default
0.35 strength. Twenty-one CPU cases cover Relax, Recalculate Normals, Flip Normals
and Remove Degenerate Faces, including scopes, no-ops, boundary preservation,
strength limits, malformed faces, creases and appearance. Editor command tests
also cover active UV maps, selection and exact undo/redo for Relax, Recalculate
Normals and Remove Degenerate Faces. Boundary-only Relax creates no history.
This is CPU behavioral coverage; the subsequent native visual pass is recorded
in [NATIVE_VERIFICATION.md](NATIVE_VERIFICATION.md).

## Closing tool verification audit

The per-action scope and evidence for the 80 catalog actions are recorded in
[TOOL_VERIFICATION.md](TOOL_VERIFICATION.md), including native-validation limits and
scene-layer integration. Additional current Swift references cover document
transforms, origins, selection, copying/joining/deletion, Circlify, Edge Slide,
primitives and Sub-D. The closing audit fixes Cylinder/Torus inward winding,
polygon cylinder cap UVs, Circlify/Edge Slide UV winding repair, live Edge Slide
symmetry, Duplicate/Separate hidden faces, Duplicate batch names and animation
tracks, and active-object selection. Sculpt remains excluded. Equal fractional Sub-D crease ties are checked against
Swift's permitted outcomes because Swift's own Set iteration is nondeterministic.


### Scene layers and native verification

Swift scene layers and object `layerID` assignments now survive decoding and both
new and preserving package saves. Array creates its named layer and group;
Duplicate/Separate retain the source layer. Serializable layer edits support
creation, rename, assignment, merge and visibility metadata through undo/redo.
Reveal All resets layer visibility too. As in current Swift, layer visibility does
not filter rendered objects; there is no extra layer-management panel.

See [native verification](NATIVE_VERIFICATION.md) for the macOS visual checks,
parented document-alert and fast native-drag fixes, two passing native GPU tests,
measured memory, and explicit coverage limits.

## Public project library

The Rust public library uses Supabase for anonymous browsing/downloads and browser-based OAuth publisher sign-in. Swift retains CloudKit. See [setup and limits](PUBLIC_LIBRARY_SETUP.md) for the migration, publisher access, OAuth setup, and hosted verification steps.

### Build output directory

Cargo writes build artifacts to `.target/`, configured in `.cargo/config.toml`.
The hidden directory keeps Xcode from scanning Rust build artifacts when it opens
the local Swift package. Desktop packages are in `.target/dist/`; Android APKs
and artist builds also use `.target/`. Run Cargo from this repository or a crate
subdirectory so it loads the workspace configuration.
